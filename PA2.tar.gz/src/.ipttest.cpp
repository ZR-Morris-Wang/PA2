
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int main() {
    ifstream input("../inputs/12.in");

    // Read the number of points on the circle
    int n;
    input >> n;
    cout << "Number of points: " << n << endl;  // Debugging output
return 0;
}
