#include <iostream>
#include <fstream>
#include <vector>
#include <utility>

using namespace std;

struct Chord {
    int start;
    int end;
};



int main() {
    vector<Chord> chords;
    int n;

    ifstream input("./inputs/1000.in");
    if (!input) {
        cerr << "Error opening file." << endl;
        return 1;
    }

    input >> n;
    cout << "Number of points: " << n << endl;
    while (true) {
        int start, end;
        input >> start;

        // Check for termination condition
        if (start == 0) {
            if (input.peek() == '\n' || input.eof()) {
                break;  // Terminating condition
            } else {
                input >> end;
                chords.push_back({start, end});
                cout << "Read chord: " << start << " " << end << endl;  // Debugging output
                continue;  // Continue to read the next chord
            }
        }

        // Read the end value only if the start is not 0
        input >> end;
        chords.push_back({start, end});
        cout << "Read chord: " << start << " " << end << endl;  // Debugging output
    }

    vector<Chord> subset;
    // int maxCount = mps(0, n, subset);

    // cout << maxCount << endl;
    for (const auto& c : subset) {
	    cout << c.start << " " << c.end << endl;
    }

    return 0;
}

